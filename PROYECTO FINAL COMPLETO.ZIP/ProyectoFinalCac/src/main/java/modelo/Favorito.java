package modelo;

import java.sql.Date;

public class Favorito {
    private int idFavorito;
    private String nombre;
    private String categoria;
    private String descripcion;
    private Date fecha;

    // Constructor
    public Favorito() {
    }

    // Getters y setters
    // ...
    public int getIdFavorito() {
        return idFavorito;
    }

    public void setIdFavorito(int idFavorito) {
        this.idFavorito = idFavorito;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
    // Resto de métodos y atributos
    // ...
    
}
