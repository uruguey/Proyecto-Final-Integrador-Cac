package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Favorito;
import util.ConexionDB;

public class FavoritoDAO {
    public void agregarFavorito(Favorito favorito) {
        String sql = "INSERT INTO favorito (nombre, categoria, descripcion, fecha) VALUES (?, ?, ?, ?)";
        //bloque try-with-resources
        //asegura que los recursos abiertos en su declaración (dentro de los paréntesis) se cierren automáticamente al final del bloque try 
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, favorito.getNombre());
            pstmt.setString(2, favorito.getCategoria());
            pstmt.setString(3, favorito.getDescripcion());
            pstmt.setDate(4, favorito.getFecha());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Favorito obtenerPorId(int id) {
        String sql = "SELECT * FROM favorito WHERE id_favorito = ?";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                Favorito favorito = new Favorito();
                favorito.setIdFavorito(rs.getInt("id_favorito"));
                favorito.setNombre(rs.getString("nombre"));
                favorito.setCategoria(rs.getString("categoria"));
                favorito.setDescripcion(rs.getString("descripcion"));
                favorito.setFecha(rs.getDate("fecha"));
                return favorito;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Favorito> obtenerTodos() {
        List<Favorito> favoritos = new ArrayList<>();
        String sql = "SELECT * FROM favorito ";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Favorito favorito = new Favorito();
                favorito.setIdFavorito(rs.getInt("id_favorito"));
                favorito.setNombre(rs.getString("nombre"));
                favorito.setCategoria(rs.getString("categoria"));
                favorito.setDescripcion(rs.getString("descripcion"));
                favorito.setFecha(rs.getDate("fecha"));
                favoritos.add(favorito);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return favoritos;
    }

    public void actualizarFavorito(Favorito favorito) {
        String sql = "UPDATE favorito SET nombre = ?, categoria = ?, descripcion = ?, fecha = ? WHERE id_favorito = ?";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, favorito.getNombre());
            pstmt.setString(2, favorito.getCategoria());
            pstmt.setString(3, favorito.getDescripcion());
            pstmt.setDate(4, favorito.getFecha());
            pstmt.setInt(5, favorito.getIdFavorito());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void eliminarFavorito(int id) {
        String sql = "DELETE FROM favorito WHERE id_favorito = ?";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
