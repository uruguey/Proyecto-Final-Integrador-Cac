package controlador;

import dao.FavoritoDAO;
import modelo.Favorito;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import java.io.IOException;

@WebServlet("/vistas/GestionFavoritoServlet")
public class GestionFavoritoServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String accion = request.getParameter("accion");
        FavoritoDAO favoritosDAO = new FavoritoDAO();

        // Inicializar idFavorito antes del switch para que esté disponible en todos los casos
        int idFavorito = Integer.parseInt(request.getParameter("id"));

        switch (accion) {
            case "actualizar":
                Favorito favorito = favoritosDAO.obtenerPorId(idFavorito);
                request.setAttribute("favorito", favorito); //Esto permite pasar datos del servlet a una vista (como un archivo JSP) o a otro servlet al que se redirige o se reenvía la solicitud
                request.getRequestDispatcher("actualizar.jsp").forward(request, response);
                break;
            case "confirmarActualizacion":
                Favorito favoritoActualizado = new Favorito();
                favoritoActualizado.setIdFavorito(idFavorito);
                favoritoActualizado.setNombre(request.getParameter("nombre"));
                favoritoActualizado.setCategoria(request.getParameter("categoria"));
                favoritoActualizado.setDescripcion(request.getParameter("descripcion"));
                // Asume que el método setFecha acepta un java.sql.Date
                favoritoActualizado.setFecha(java.sql.Date.valueOf(request.getParameter("fecha")));

                favoritosDAO.actualizarFavorito(favoritoActualizado);
                response.sendRedirect("gestionFavorito.jsp");
                break;
            case "eliminar":
                favoritosDAO.eliminarFavorito(idFavorito);
                response.sendRedirect("gestionFavorito.jsp");
                break;
            default:
                response.sendRedirect("gestionFavorito.jsp");
                break;
        }
    }
}
