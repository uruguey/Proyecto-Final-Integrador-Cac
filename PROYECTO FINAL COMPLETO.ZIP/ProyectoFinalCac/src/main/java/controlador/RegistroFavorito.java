package controlador;

import dao.FavoritoDAO;
import modelo.Favorito;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;

@WebServlet("/RegistroFavorito")
public class RegistroFavorito extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Obtener datos del formulario
        String nombre = request.getParameter("nombre");
        String categoria = request.getParameter("categoria");
        String descripcion = request.getParameter("descripcion");

        // Crear un objeto Favorito con los datos
        Favorito favorito = new Favorito();
        favorito.setNombre(nombre);
        favorito.setCategoria(categoria);
        favorito.setDescripcion(descripcion);

        // Obtener la fecha actual
        java.util.Date fechaActual = new java.util.Date(); //es una forma de utilizar la clase sin necesitar una declaracion 'import'
        favorito.setFecha(new Date(fechaActual.getTime()));

        // Agregar el favorito a la base de datos
        FavoritoDAO favoritosDAO = new FavoritoDAO();
        favoritosDAO.agregarFavorito(favorito);

        // Redireccionar a la página de visualización de favoritos
        response.sendRedirect(request.getContextPath() + "/vistas/verFavoritos.jsp");
    }
}
