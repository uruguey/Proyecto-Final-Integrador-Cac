# ProyectoIntegrador1cac
Proyecto integrador del Programa Codo a Codo, competencias en HTML y CSS.
Se Incluye el dia 5/11/2023 competencias con javascript Dark Mode y Descuentos segun formas de pago.

![Calculo de ahorro](https://github.com/uruguey/ProyectoIntegrador1cac/assets/80857760/c41680f8-3989-408c-abaa-bd447b57e397)
![darkmode](https://github.com/uruguey/ProyectoIntegrador1cac/assets/80857760/3254ff4d-48a4-4733-92e5-536af3122a84)
